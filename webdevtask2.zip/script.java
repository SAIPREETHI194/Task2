<script>
  const form = document.getElementById('contactForm');

  form.addEventListener('submit', function (e) {
    e.preventDefault(); // Stop form from submitting

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if (!name || !email || !message) {
      alert('Please fill in all fields.');
    } else if (!emailPattern.test(email)) {
      alert('Please enter a valid email address.');
    } else {
      alert('Form submitted successfully!');
      form.reset();
    }
  });
</script>